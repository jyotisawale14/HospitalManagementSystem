package com.example.springboot.exception;

public class RoomDuplicateException extends Exception{

	public RoomDuplicateException(String msg) {
		super(msg);
	}
	 

}
